package ch03.sec02;

public class VariableInitialzationgExample {
	
	public static void main(String[] args) {
		// 변수 value 선언
		int value = 0;
		
		//연산 결과를 변수 result의 초기값으로 대입
		int result = value;
		
		//변수 result 값읅 읽고 콘솔에 입력
		System.out.println(result);
	}


}
