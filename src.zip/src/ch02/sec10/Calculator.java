package ch02.sec10;

public class Calculator {
	
	public static void main(String[] args) {
		int x=1;
		int y=2;
		int result = x+y; //변수 = 이름식별자
		System.out.println(result);
	}
}
