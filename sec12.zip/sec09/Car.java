package ch06.sec09;

public class Car {

}
