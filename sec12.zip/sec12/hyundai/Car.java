package ch06.sec12.hyundai;

public class Car {

}
