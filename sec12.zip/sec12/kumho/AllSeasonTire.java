package ch06.sec12.kumho;

public class AllSeasonTire {

}
