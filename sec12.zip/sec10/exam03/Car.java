package ch06.sec10.exam03;

public class Car {

}
