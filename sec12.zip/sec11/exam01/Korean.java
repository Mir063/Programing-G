package ch06.sec11.exam01;

public class Korean {

}
