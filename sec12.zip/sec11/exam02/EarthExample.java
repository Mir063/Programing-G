package ch06.sec11.exam02;

public class EarthExample {

}
