package ch06.sec14;

public class CarExample {
	
	public static void main(String[] args) {
		
		Car myCar = new Car();
		
		myCar.Setspeed(-50);
		System.out.println("현재속도: "+myCar.getSpeed());
		
		myCar.Setspeed(60);
		System.out.println("현재속도: "+myCar.getSpeed());
		
		if(!myCar.isStop()) {
			myCar.setStop(true);
		}
		System.out.println("현재속도 "+myCar.getSpeed());
	}
}
