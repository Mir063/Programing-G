package ch06.sec13.exam03.package1;

public class C {

}
