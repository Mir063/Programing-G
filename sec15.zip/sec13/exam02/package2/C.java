package ch06.sec13.exam02.package2;

public class C {

}
